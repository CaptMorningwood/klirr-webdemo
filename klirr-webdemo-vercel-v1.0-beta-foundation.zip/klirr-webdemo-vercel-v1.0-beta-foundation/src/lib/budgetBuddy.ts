import type { BuddyAction, BudgetSummary, ChatMessage, DetectionResult, Rule } from '../types';
import { fmt, fmtSigned, todayIso, uid } from './format';

export interface BuddyContext {
  summary: BudgetSummary;
  detection: DetectionResult;
  rules: Rule[];
}

export function initialBuddyMessage(): ChatMessage {
  return {
    id: uid('msg'),
    role: 'assistant',
    createdAt: todayIso(),
    content: 'Hej! Jag är Budget Buddy. Jag hjälper dig förstå vad livet kostar varje månad, hitta oklara poster och navigera i Klirr. Fråga mig till exempel: ”Vad ska jag göra först?” eller ”Vad kan jag kapa?”',
  };
}

function topDrivers(summary: BudgetSummary) {
  return [...summary.fixedItems, ...summary.variableItems].sort((a, b) => b.amount - a.amount).slice(0, 5);
}

export function makeBuddyReply(question: string, ctx: BuddyContext): ChatMessage {
  const q = question.toLowerCase();
  const s = ctx.summary;
  const drivers = topDrivers(s);
  let content = '';
  const actions: BuddyAction[] = [];

  if (q.includes('först') || q.includes('börja') || q.includes('nästa')) {
    content = `Jag skulle börja i den här ordningen:\n\n1. Granska oklara poster (${ctx.detection.reviewItems.length} st) så kalkylen blir rätt.\n2. Kontrollera månadens måsten: ${fmt(s.fixedTotal)}.\n3. Titta på din marginal efter hela planen: ${fmtSigned(s.remainingAfterPlan)}.\n\nOm marginalen är låg är det mest värdefullt att justera rörlig plan eller testa scenario på en större kostnad, inte fastna i småköp direkt.`;
    actions.push({ label: 'Gå till oklara poster', tab: 'review' }, { label: 'Visa måsten', tab: 'musts' }, { label: 'Testa scenario', tab: 'scenarios' });
  } else if (q.includes('förklara') || q.includes('ekonomi') || q.includes('sammanfatta')) {
    content = `Så här ser din månad ut just nu:\n\n• Inkomster: ${fmt(s.totalIncome)}\n• Månadens måsten: ${fmt(s.fixedTotal)}\n• Kvar efter måsten: ${fmtSigned(s.remainingAfterFixed)}\n• Rörlig plan: ${fmt(s.variablePlanTotal)}\n• Kvar efter total plan: ${fmtSigned(s.remainingAfterPlan)}\n\nDe största posterna är:\n${drivers.map((d, i) => `${i + 1}. ${d.label}: ${fmt(d.amount)}`).join('\n')}`;
    actions.push({ label: 'Öppna översikt', tab: 'dashboard' }, { label: 'Öppna rörlig plan', tab: 'variablePlan' });
  } else if (q.includes('kapa') || q.includes('spara') || q.includes('minska') || q.includes('förbättra')) {
    const variable = [...s.variableItems].sort((a, b) => b.amount - a.amount).slice(0, 4);
    content = `Tre rimliga förbättringsspår:\n\n1. Justera rörlig plan. Det är snabbast och påverkar direkt. Rörlig plan är nu ${fmt(s.variablePlanTotal)}.\n2. Testa scenario på större valfria poster. Små abonnemang kan hjälpa, men en större kostnad gör mer skillnad.\n3. Bekräfta oklara poster så du inte budgeterar för engångar.\n\nStörsta rörliga/justerbara posterna just nu:\n${variable.map((v) => `• ${v.label}: ${fmt(v.amount)}`).join('\n') || 'Jag hittar inga rörliga poster än.'}`;
    actions.push({ label: 'Ändra rörlig plan', tab: 'variablePlan' }, { label: 'Bygg scenario', tab: 'scenarios' });
  } else if (q.includes('oklar') || q.includes('otydlig') || q.includes('granska')) {
    content = ctx.detection.reviewItems.length
      ? `Jag hittar ${ctx.detection.reviewItems.length} oklara poster. De vanligaste orsakerna är möjliga engångskostnader, dubletter, plusposter eller låg säkerhet i återkommande-detektionen. Börja med de största beloppen först.`
      : 'Just nu finns inga oklara poster. Snyggt! Då är nästa steg att bekräfta återkommande utgifter och justera rörlig plan.';
    actions.push({ label: 'Gå till oklara poster', tab: 'review' });
  } else if (q.includes('kris') || q.includes('stram')) {
    const removable = s.variableItems.filter(x => x.source === 'variablePlan').map(x => x.id);
    content = `Krisläge betyder att vi bara räknar måsten och kapar rörlig plan tillfälligt.\n\nMed dagens siffror:\n• Måsten: ${fmt(s.fixedTotal)}\n• Kvar efter måsten: ${fmtSigned(s.remainingAfterFixed)}\n\nDet är inte ett långsiktigt liv, men det visar miniminivån för att klara månaden.`;
    actions.push({ label: 'Testa kris-scenario', tab: 'scenarios', scenarioOffIds: removable });
  } else if (q.includes('import') || q.includes('kontoutdrag') || q.includes('csv')) {
    content = 'Ladda upp kontoutdrag under Importera. När du har importerat flera konton ska du markera vilka som är dina egna. Då kan Klirr räkna överföringar mellan dina egna konton som interna, inte som inkomst eller utgift.';
    actions.push({ label: 'Gå till import', tab: 'import' }, { label: 'Visa konton', tab: 'accounts' }, { label: 'Visa interna överföringar', tab: 'transfers' });
  } else if (q.includes('regel') || q.includes('kategori')) {
    content = 'Regler är Klirrs sätt att komma ihåg dina beslut. Om du säger “Telia = streaming” eller “Matboden = mat” ska den regeln gå före automatisk gissning nästa gång.';
    actions.push({ label: 'Gå till regler', tab: 'rules' });
  } else {
    content = `Jag kan hjälpa dig tolka månaden, hitta kostnader att kapa, granska oklara poster och visa var i Klirr du ska gå.\n\nJag kan också hjälpa dig hitta rätt i appen: Import, Konton, Måsten, Inkomst, Regler eller Scenario.

Just nu är din totala månadsplan ${fmt(s.totalMonthlyPlan)} och marginalen efter planen är ${fmtSigned(s.remainingAfterPlan)}. Vad vill du titta på först?`;
    actions.push({ label: 'Vad ska jag göra först?', message: 'Vad ska jag göra först?' }, { label: 'Förklara min ekonomi', message: 'Förklara min ekonomi' });
  }

  return { id: uid('msg'), role: 'assistant', content, actions, createdAt: todayIso() };
}

export const buddySuggestions = [
  'Vad ska jag göra först?',
  'Förklara min ekonomi',
  'Vad kan jag kapa?',
  'Vad är oklart?',
  'Gör krisbudget',
  'Hur importerar jag kontoutdrag?',
  'Hur ändrar jag konton?',
];
